////////////////////////////
//// EVENT INFO LIBRARY ////
//// ------------------ //////////////////////
//// Clase para el manejo de los eventos  ////
//////////////////////////////////////////////
#ifndef _H_EVENT_INFO

#define _H_EVENT_INFO
#include "viewer.h"
#include <allegro5\allegro.h>
#include <iostream>
#include <vector>
#include "worms.h"
#include "stdafx.h"
#include "possition.h"

#define FPS 50.0
enum  eventype { QUIT, ATM, STM, ATS, STS, REFRESH, NO_EVENT };

class eventInfo {
private:
	unsigned int eventData;
	unsigned int userData;
	unsigned int framecnt_a;
	
	ALLEGRO_EVENT ev;
	ALLEGRO_TIMER *timerA = nullptr;
	ALLEGRO_EVENT_QUEUE *buffer = nullptr;

public:
	eventInfo(ALLEGRO_DISPLAY *disp){
		buffer = al_create_event_queue();
		if (!buffer) {
			fprintf(stderr, "failed to create event_queue!\n");
			isinitok = false;
		}
		al_register_event_source(buffer, al_get_display_event_source(disp));
		int is_ok = this->init_allegro_timer();
		if (!is_ok) {
			fprintf(stderr, "failed to create timer!\n");
			isinitok = false;
		}
		al_register_event_source(buffer, al_get_timer_event_source(timerA));
		if (!al_install_keyboard()) {
			fprintf(stderr, "failed to initialize the keyboard!\n");
			isinitok = false;
		}
		al_register_event_source( buffer, al_get_keyboard_event_source());

		al_start_timer(timerA);
	}
	~eventInfo() {
		al_destroy_timer(timerA);
		al_destroy_event_queue(buffer);
	}
	eventInfo(unsigned int eventData_, unsigned int userData_);
	bool isinitok = true;
	void getNextEvent();
	unsigned int getEventData();
	unsigned int getUserData();
	int init_allegro_timer();
	void setEventData(unsigned int eventData_);
	void setUserData(unsigned int userData_);
};

#endif // !_H_EVENT_INFO

