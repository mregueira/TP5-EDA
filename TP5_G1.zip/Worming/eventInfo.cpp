#include "eventInfo.h"

using namespace std;

eventInfo::eventInfo(unsigned int eventData_, unsigned int userData_) {
	this->eventData = eventData_;
	this->userData = userData_;
	this->framecnt_a = 0;
}

void eventInfo::getNextEvent()
{
	if (framecnt_a > 250) {
		// Se vacia la cola cada 5 seg
		// Hay perdida de eventos pero evita llenar la cola y enlentecer el flujo del programa
		al_flush_event_queue(buffer); 
		framecnt_a = 0;
	}

	al_get_next_event(buffer, &ev);
	if ((ev.type) == ALLEGRO_EVENT_KEY_DOWN) {
		unsigned int key = ev.keyboard.keycode;
		if ((key == ALLEGRO_KEY_A) || (key == ALLEGRO_KEY_D) || (key == ALLEGRO_KEY_LEFT) || (key == ALLEGRO_KEY_RIGHT)) {
			setUserData(key);
			setEventData(ATM);
		}
		else if ((key == ALLEGRO_KEY_W) || (key == ALLEGRO_KEY_UP)) {
			setUserData(key);
			setEventData(ATS);
		}
		else if (key == ALLEGRO_KEY_ESCAPE) {
			setUserData(NULL);
			setEventData(QUIT);
		}
	}
	else if ((ev.type) == ALLEGRO_EVENT_KEY_UP) {
		unsigned int key = ev.keyboard.keycode;
		if ((key == ALLEGRO_KEY_A) || (key == ALLEGRO_KEY_D) || (key == ALLEGRO_KEY_LEFT) || (key == ALLEGRO_KEY_RIGHT)) {
			setUserData(key);
			setEventData(STM);
		}
		else if ((key == ALLEGRO_KEY_W) || (key == ALLEGRO_KEY_UP)) {
			setUserData(key);
			setEventData(STS);
		}
	}
	else if ((ev.type) == ALLEGRO_EVENT_DISPLAY_CLOSE) {
		setUserData(NULL);
		setEventData(QUIT);
	}
	else if ((ev.type) == ALLEGRO_EVENT_TIMER) {
		setUserData(NULL);
		setEventData(REFRESH);
		framecnt_a++;
	}
	else {
		setUserData(NULL);
		setEventData(NO_EVENT);
	}
}

int eventInfo::init_allegro_timer()
{
	timerA = al_create_timer(1.0 / FPS);
	if (!timerA) {
		cout << "failed to create timer!\n" << endl;
		return 0;
	}

	

	return 1;
}

// Getters //
// ------- //
unsigned int eventInfo::getEventData() { return this->eventData; }
unsigned int eventInfo::getUserData() { return this->userData; }
// ------- //

// Setters //
// ------- //
void eventInfo::setEventData(unsigned int eventData_) { this->eventData = eventData_;  }
void eventInfo::setUserData(unsigned int userData_) { this->userData = userData_;  }
// ------- //