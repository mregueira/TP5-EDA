#pragma once
#ifndef _H_MAIN
#define _H_MAIN
#define ALLEGRO_STATICLINK

#include "worms.h"
#include "stdafx.h"
#include <iostream>
#include <vector>
#include "eventInfo.h"
#include "viewer.h"
#include <allegro5\allegro.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>
#include <string>
#include <cmath>
#include "possition.h"

#define FPS 50.0
#define RIGHT_WALL 1212
#define LEFT_WALL 701
#define FLOOR 616
#define START_X_1 750
#define START_X_2 1198
#define START_Y 616

void dispatch(eventInfo& ev, viewer& view, vector<worms>& worm);

#endif