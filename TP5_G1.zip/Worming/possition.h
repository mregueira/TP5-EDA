//////////////////////////
//// POSITION LIBRARY ////
//// ---------------- //////////////////////
//// Clase para el manejo de posiciones ////
//// Utiliza coordenadas cartesianas    ////
////////////////////////////////////////////
#pragma once
#ifndef POSSITION_H_
#define POSSITION_H_


class position
{
public:
	position(double x_ = 0.0, double y_ = 0.0);
	double getX(void);
	double getY(void);
	void setX(double x_);
	void setY(double y_);
	~position();   /////////////
	double x;
	double y;
private:
	
};

#endif //!POSSITION_H_