// TP5EDA.cpp : Defines the entry point for the console application.
//
#include "main.h"

using namespace std;

int main()
{
	if (!al_init()) {
		cout << "failed to initialize allegro!" << endl;
		return -1;
	}

	ALLEGRO_SAMPLE *music;

	al_install_audio();
	al_init_acodec_addon();
	al_reserve_samples(1);
	music = al_load_sample("Kerning.ogg");
	if (music == NULL) {
		cout << "failed to load sample!" << endl;
		return -1;
	}
	
	viewer view;
	
	int is_ok_v = view.init_allegro();
	if (!is_ok_v) {
		return -1; // Error en la inicializacion grafica
	}
	
	eventInfo cevent(view.getDisplay()); 
	if (!cevent.isinitok) {
		return -1; // Error en la inicializacion de manejo de eventos
	}
	
	vector<worms>worm(2);
	
	worm[0].setKeys(ALLEGRO_KEY_A, ALLEGRO_KEY_D, ALLEGRO_KEY_W); 
	worm[1].setKeys(ALLEGRO_KEY_LEFT, ALLEGRO_KEY_RIGHT, ALLEGRO_KEY_UP); 
	worm[0].setPos(START_X_1, START_Y); 
	worm[1].setPos(START_X_2, START_Y); 
	worm[0].setDir(1);
	al_play_sample(music,1,0,1,ALLEGRO_PLAYMODE_LOOP,0);

	do {
		cevent.getNextEvent();
		dispatch(cevent, view, worm);
	} while (cevent.getEventData() != QUIT);
	al_uninstall_audio();
    return 0;
}

void dispatch(eventInfo& ev, viewer& view, vector<worms>& worm)
{
	position p;
	
	switch (ev.getEventData())
	{
	case QUIT:
		// No se hace nada aqui
		// Cuando sale del dispatcher termina el programa solo
		break;
	case ATM:
		// En userData esta la tecla valida apretada, se la pasa al worms
		// va a tener A, D, flecha izq o flecha der, en codigos de allegro	
		for (int i = 0; i < worm.size(); i++) {
			p = worm[i].getPos();
			if (ev.getUserData() == ALLEGRO_KEY_A || ev.getUserData() == ALLEGRO_KEY_LEFT) {
				if (p.getX() > LEFT_WALL)
					worm[i].startMov(ev.getUserData());		    
			}else if( (ev.getUserData() == ALLEGRO_KEY_D) || (ev.getUserData() == ALLEGRO_KEY_RIGHT) )
				if (p.getX() < RIGHT_WALL)
					worm[i].startMov(ev.getUserData());
		}										
		break;
	case STM:
		// En userData esta la tecla valida soltada, se la pasa al worms
		// va a tener A, D, flecha izq o flecha der, en codigos de allegro 
		for (int i = 0; i < worm.size(); i++) 
			worm[i].stopMov(ev.getUserData());
		break;
	case ATS:
		// En userData esta la tecla valida apretada, se la pasa al worms
		// va a tener W o flecha arriba, en codigos de allegro 
		// que podes ver en el getNextEvent como se llama cada una
		for (int i = 0; i < worm.size(); i++) 
			worm[i].startJum(ev.getUserData());
		break;
	case STS:
		// En userData esta la tecla valida soltada, se la pasa al worms
		// va a tener W o flecha arriba, en codigos de allegro 
		// que podes ver en el getNextEvent como se llama cada una
		for (int i = 0; i < worm.size(); i++)
			worm[i].stopJum(ev.getUserData());
		break;
	case REFRESH:
		// Aca se llama a refresh 2 veces, una con cada worm y luego se llama a update_display,
		// donde status es: "idle", "moving", "monitor_moving", "jump", "end_move", "end_jump"
		for (int i = 0; i < worm.size(); i++) {
			
			worm[i].Update();
			
			p = worm[i].getPos();
			
			// Chequeo de bordes
			if (p.getX() > RIGHT_WALL) { 
				p.setX(RIGHT_WALL);
				worm[i].setPos(p);
			}
			else if (p.getX() < LEFT_WALL) {
				p.setX(LEFT_WALL);
				worm[i].setPos(p);
			}
			if (p.getY() > FLOOR) {
				p.setY(FLOOR);
				worm[i].setPos(p);
			}
			
			view.refresh( worm[i].getState(), worm[i].getFrame(), p.getX(), p.getY(), worm[i].getDir());
			
		}
		view.update_display();
		break;
	case NO_EVENT:
		// Does nothing
		break;
	}
}


