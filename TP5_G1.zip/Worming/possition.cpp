#include "possition.h"

using namespace std;

position::position(double x_, double y_)
{
	x = x_;
	y = y_;
}

double position :: getX(void)
{
	return x;
}
void position::setX(double x_)
{
	x = x_;
}
double position::getY(void)
{
	return y;
}
void position::setY(double y_)
{
	y = y_;
}


position::~position()
{
}
