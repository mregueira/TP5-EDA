////////////////////////
//// VIEWER LIBRARY ////
//// -------------- //////////////////////////////
//// Clase para el manejo de la parte grafica ////
//// Asume que al_init() ya fue ejecutado     ////
//////////////////////////////////////////////////
#pragma once
#ifndef VIEWER_H
#define VIEWER_H
#include <string>
#include <iostream>
#include <allegro5\allegro.h>
#include <allegro5\allegro_image.h>
#include "worms.h"
#include "stdafx.h"

using namespace std;

#define WWALKING 15
#define WJUMP 10

class viewer
{
public:
	viewer();
	~viewer();
	int init_allegro(void); // Inicializacion de addons y carga de imagenes
	void refresh(stateType status, unsigned int frames, double pos_x, double pos_y, int dir); // Modifica la posicion en pantalla
	void update_display(void); // Actualiza los estados en el display
	ALLEGRO_DISPLAY *getDisplay(void); // Para registrar los eventos asociados

private:
	ALLEGRO_DISPLAY *display;
	ALLEGRO_BITMAP *background;
	ALLEGRO_BITMAP *background_2;
	ALLEGRO_BITMAP *wwalking[WWALKING];
	ALLEGRO_BITMAP *wjump[WJUMP];
	ALLEGRO_BITMAP *smallBuffer;
	ALLEGRO_BITMAP *drawingBoard;

	void close_allegro(void); // Es llamada por el destructor unicamente
};

#endif // !VIEWER_H

